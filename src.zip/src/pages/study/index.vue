<template>
	<div class="study">
		<mo-tops></mo-tops>
		<mo-study></mo-study>
		<mo-bottom></mo-bottom>
	</div>
</template>
<script>
import MoTops from '@/components/tops'
import MoBottom from '@/components/bottom'
import MoStudy from './components/study'

	export default{
		components:{
			MoTops,
			MoBottom,
			MoStudy
		},
		methods:{
			
		},
	}
</script>
<style scoped>

</style>