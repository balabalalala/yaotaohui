<template>
	<div class="goodteacher">
		<div class="title">不凡手绘视觉传达导师：</div>
		<div class="des">
			<p>1946年生, 广州人,	设计理论和设计史专家  ，现代设计和现代设计教育的重要奠基人之一。1987年作为富布赖特学者，在宾夕法尼亚州立大学切斯特学院和威斯康星大学麦迪逊学院从事设计理论研究和教学。现为美国设计教育最高学府———美国艺术中心设计学院教授，美国南加州建筑学院教授，中国汕头大学长江艺术与设计学院院长，加拿大楷硕建筑设计有限公司总顾问  。 光华龙腾奖中国设计贡献奖金质奖章获得者。  
      		</p>
			<p>兼任中央美术学院、清华大学美术学院、鲁迅美术学院、上海大学美术学院、汕头大学长江艺术与设计学院等高等艺术设计院校院长。
      		</p>
			<p>他还在美国奥迪斯艺术与设计学院、加州美术学院、南加州建筑学院和洛杉矶南加州大学教授设计类课程。设计理论家，曾编有《世界现代设计史》《世界平面设计史》等。</p>
		</div>
	</div>
</template>
<script>

	export default{
		// created(){
		// 	console.log('监测是否进入')
		// }
	}
</script>
<style scoped>
	.goodteacher{
		width: 375px;
		/*background-color: red;*/
	}
	.goodteacher .title{
		width: 100%;
		height: 30px;
		font-size: 22px;
		color: #000000;
		margin-top: 60px;
		line-height: 30px;
		text-align: center;
		font-family: PingFangSC-Semibold;
	}
	.goodteacher .des{
		width: 330px;
		height: 630px;
		font-size: 16px;
		color: #797979;
		line-height: 28px;
		margin-left: 23px;
		margin-top: 15px;
		text-align: left;
	}
	.goodteacher .des p{
		text-indent: 30px;
	}
</style>