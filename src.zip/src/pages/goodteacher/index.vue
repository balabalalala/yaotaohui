<template>
	<div class="goodteacher">
		<mo-tops></mo-tops>
		<mo-goodteacher></mo-goodteacher>
		<mo-bottom></mo-bottom>
	</div>
</template>
<script>
import MoTops from '@/components/tops'
import MoBottom from '@/components/bottom'
import MoGoodteacher from './components/goodteacher'

	export default{
		components:{
			MoTops,
			MoBottom,
			MoGoodteacher
		},
		methods:{
			
		},
	}
</script>
<style scoped>

</style>