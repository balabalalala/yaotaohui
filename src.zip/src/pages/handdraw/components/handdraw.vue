<template>
	<div class="handdraw">
		<div class="box top">
			<img class=""  src="@/assets/jigou/one.png" alt="sorry">
		</div>
		
		<div class="box two">
			<router-link tag="div" to="goodteacher" class="case two-left">
			<img class="left" src="@/assets/jigou/two.png" alt="sorry">
			</router-link>
			<router-link tag="div" to="/smallclass" class="case two-right">
				<img class="right" src="@/assets/jigou/three.png" alt="sorry">
			</router-link>
		</div>
		
		<router-link tag="div" to="aboutwe"  class="box aboutwe">
			<img class="aboutimg" src="@/assets/jigou/four.png" alt="sorry">
		</router-link>
		<router-link tag="div" to="study" class="box study">
			<img class="studyimg" src="@/assets/jigou/shouhui.png" alt="sorry">
		</router-link>
	</div>
</template>
<script>
	export default{
		components:{
		},
	}
</script>
<style scoped>
	.handdraw{
		width: 375px;
		margin-bottom: 50px;
		/*background-color: red;*/
	}
	.handdraw .box{
		width: 100%;
		height: 140px;
	}
	.handdraw .box img{
		height: 120px;
	}
	.handdraw .top{
		width: 100%;
		margin:60px auto 0;
	}
	.handdraw .two {
		/*position: relative;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;*/
		width: 100%;
		height: 120px;
		margin:50px auto 0;
	}
	.handdraw .two .case{
		float: left;

	}
	.handdraw .two .two-left{
		/*position: absolute;
		top: 0;*/
		/*left: 5px;*/
		width: 170px;
		height: 120px;
		padding-left: 20px;
	}
	.handdraw .two  .two-right{
		/*position: absolute;
		top: 0;*/
		/*right: 5px;*/
		width: 170px;
		height: 120px;
	}
	.handdraw .aboutwe{
		width: 350px;
		margin:20px auto 0;
	}
	.handdraw .studyimg{
		width: 350px;
		height: 140px;
	}
</style>