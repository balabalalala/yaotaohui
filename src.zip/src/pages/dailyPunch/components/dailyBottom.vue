<template>
    <div class="daily-bottom">
        <span class="say">发表感言</span>
        <input type="text" class="write">
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped lang='styl'>
    .daily-bottom{
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 41px;
        background: #fff;
        z-index: 5;
        .say{
            position: absolute;
            left: 28px;
            top: 15px;
            font-size: 16px;
            color: #8A8A8A;
        }
        .write{
            position: absolute;
            left: 105px;
            top: 2px;
            width: 226px;
            height: 35px;
            background: #FFFFFF;
            border: 1px solid #DADADA;
            border-radius: 8px;
        }
    }
</style>
