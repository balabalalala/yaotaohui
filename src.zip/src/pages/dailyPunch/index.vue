<template>
    <div class="daily-punch">
        <small-header></small-header>
        <xp-calendar></xp-calendar>
        <div class="daily-list">
            <daily-list  v-for="(item,index) of dailyData" :key="index" :item="item"></daily-list>
        </div>
        <daily-bottom></daily-bottom>
    </div>
</template>
<script>
import smallHeader from '@/components/smallHeader'
import xpCalendar from './components/calendar'
import dailyList from './components/dailyList'
import dailyBottom from './components/dailyBottom'
export default {
    name:'dailyPunch',
    components:{
        smallHeader,
        xpCalendar,
        dailyList,
        dailyBottom
    },
    data(){
        return{
            dailyData:[
                {
                    id:'21',
                    learn:'今天早起了'
                },
                {
                    id:'22',
                    learn:'学习了外语'
                },
                {
                    id:'23',
                    learn:'学习了政治'
                },
                {
                    id:'24',
                    learn:'学习专业课'
                },
                {
                    id:'25',
                    learn:'学习了理论'
                },
                {
                    id:'26',
                    learn:'锻炼了身体'
                },
            ]
        }
    }
}
</script>
<style scoped lang='styl'>
    .daily-punch{
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: -100px;
        background: rgba(241,241,241,0.50);
        .daily-list{
            background: rgba(241,241,241,0.50);
            margin-top: 278px;
            /* padding-bottom: 100px; */
        }
    }
</style>

