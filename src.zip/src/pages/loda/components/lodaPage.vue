<template>
    <div class="lodaPage">
        <img src="@/assets/my/loda.png" alt="">
        <p>抱歉，网络开小差了</p>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped lang="styl">
.lodaPage{
    width:100%;
    height: 600px;
    margin-top:44px;
    /* background-color: pink; */
    img{
        width:145px;
        height: 173px;
        margin:100px auto;
    }
    p{
        width:100%;
        height: 20px;
        margin-top:-80px;
        line-height: 20px;
        text-align: center;
        font-size: 20px;
        color: #3D3D3D;
    }
}
</style>
