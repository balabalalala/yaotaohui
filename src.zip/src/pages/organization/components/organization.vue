<template>
	<div class="organization">
		<div class="head">
			<div class="box">
				<img class="icon" src="@/assets/icon/Search.png" alt="sorry">
			</div>
		</div>
		<img class="top-p" src="@/assets/jigou/shouhui.png" alt="sorry">
		<div class="container">
			<p class="left">热门机构</p>
			<!-- <p class="right">不凡手绘</p> -->
			<router-link tag="div" to="handdraw" class="right">不凡手绘</router-link>
		</div>
		<ul>
			<li class="item" v-for="item in list">
				<span>{{item.p}}</span>
			</li>
		</ul>
		<ul class="location">
			<li class="detail" v-for="detail in details">
				<span>{{detail.p1}}</span>
			</li>
		</ul>
	</div>
</template>
<script>
	export default{
		data(){
			return{
				list:[
					{
					id:1,
					p:'北京'
					},
					{
					id:2,
					p:'北京'
					},
					{
					id:3,
					p:'广州'
					},
					{
					id:4,
					p:'广州'
					},
					{
					id:5,
					p:'深圳'
					},
					{
					id:6,
					p:'海南'
					},
					{
					id:7,
					p:'海南'
					},
					{
					id:8,
					p:'郑州'
					},
					{
					id:9,
					p:'郑州'
					},
					{
					id:10,
					p:'中山'
					},
					{
					id:11,
					p:'中山'
					},
					{
					id:11,
					p:'广西'
					},
					{
					id:11,
					p:'小榄'
					},
				],

				details:[
				{
					id:11,
					p1:'北京水木源手绘'
				},
				{
					id:22,
					p1:'北京水木源手绘'
				},
				{
					id:33,
					p1:'北京水木源手绘'
				},
				{
					id:44,
					p1:'北京水木源手绘'
				},
				{
					id:55,
					p1:'北京水木源手绘'
				},
				{
					id:66,
					p1:'北京水木源手绘'
				},
				{
					id:77,
					p1:'北京水木源手绘'
				},
				{
					id:88,
					p1:'北京水木源手绘'
				},
				{
					id:99,
					p1:'北京水木源手绘'
				},
				{
					id:100,
					p1:'北京水木源手绘'
				},
				{
					id:90,
					p1:'北京水木源手绘'
				},
				{
					id:92,
					p1:'北京水木源手绘'
				},
				],
			}
		},

	}
</script>
<style scoped>
.organization{
	width: 375px;
	/*background-color: red;*/

}
	.organization .head{
		position: fixed;
		left: 0;
		top: 0;
		z-index: 2;
		width: 375px;
		height: 85px;
		padding-left: 85px;
		background: #FDD003; 
		box-sizing: border-box;
	}
	.organization .head .box{
		position: relative;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		width: 233px;
		height: 30px;
		background: #FFFFFF;
		border-radius: 8px;
	}
	.organization .head .box img{
		position: absolute;
		top: 8px;
		left: 15px;
	}
	.organization .top-p{
		position: fixed;
		top: 50px;
		left: 15px;
		width: 345px;
		height: 82px;
		z-index: 2;
	}
	.organization .container{
		position: relative;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		margin-top: 140px;
		width: 100%;
	}
	.organization .container .left{
		width: 116px;
		height: 55px;
		background: #FDD003;
		text-align: center;
		line-height: 55px;
		font-size: 18px;
		color: #000000;
	}
	.organization .container .right{
		position: absolute;
		top: 0;
		right: 0;
		width: 258px;
		height: 55px;
		text-align: center;
		line-height: 55px;
		font-size: 16px;
		color: #000000;
	}
	.organization ul{
		width: 116px;
		background: #F1F1F1;
	}
	.organization ul li{
		width: 100%;
		height: 35px;
		padding-top: 10px;
	}
	.organization ul .item{
		width: 100%;
		height: 35px;
		padding-top: 10px;
		background: #fff;
		margin-bottom: 5px;
	}
	.organization ul li span{
		font-size: 16px;
		color: #666666;
		text-align: center;
		line-height: 32px;

	}
	.organization .location{
		position: absolute;
		top: 210px;
		right: 0;
		width: 258px;
		
	}
	.organization .location li{
		width: 100%;
	}
	.organization .location li span{
		font-size: 16px;
		color: #666666;
	}
</style>