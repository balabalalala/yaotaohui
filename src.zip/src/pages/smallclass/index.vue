<template>
	<div class="smallclass">
		<mo-tops></mo-tops>
		<mo-smallclass></mo-smallclass>
		<mo-bottom></mo-bottom>
	</div>
</template>
<script>
import MoTops from '@/components/tops'
import MoBottom from '@/components/bottom'
import MoSmallclass from './components/smallclass'

	export default{
		components:{
			MoTops,
			MoBottom,
			MoSmallclass
		},
		methods:{
			
		},
	}
</script>
<style scoped>

</style>