<template>
	<div class="onlineapply">
		<mo-tops></mo-tops>
		<mo-onlineapply></mo-onlineapply>
	</div>
</template>
<script>
import MoTops from '@/components/tops'
import MoOnlineapply from './components/onlineapply'

	export default{
		components:{
			MoTops,
			MoOnlineapply
		},
		methods:{
			
		},
	}
</script>
<style scoped>

</style>onlinesonsult