<template>
	<div class="show">
		
		<mo-show></mo-show>
	</div>
</template>
<script>
import MoShow from 'show'
	export default{
		components:{
			MoShow
		},
	}
</script>
<style scoped>
	
</style>