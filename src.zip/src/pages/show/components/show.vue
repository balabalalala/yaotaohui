<template>
	<div class="show">
		666666
	</div>
</template>
<script>
	export default{
	}
</script>
<style scoped>
	
</style>