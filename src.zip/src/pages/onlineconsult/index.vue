<template>
	<div class="onlineconsult">
		<mo-tops></mo-tops>
		<mo-onlineconsult></mo-onlineconsult>
	</div>
</template>
<script>
import MoTops from '@/components/tops'
import MoOnlineconsult from './components/onlineconsult'

	export default{
		components:{
			MoTops,
			MoOnlineconsult
		},
		methods:{
			
		},
	}
</script>
<style scoped>

