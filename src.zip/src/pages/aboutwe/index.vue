<template>
	<div class="aboutwe">
		<mo-tops></mo-tops>
		<mo-aboutwe></mo-aboutwe>
		<mo-bottom></mo-bottom>
	</div>
</template>
<script>
import MoTops from '@/components/tops'
import MoBottom from '@/components/bottom'
import MoAboutwe from './components/aboutwe'

	export default{
		components:{
			MoTops,
			MoBottom,
			MoAboutwe
		},
		methods:{
			
		},
	}
</script>
<style scoped>

</style>