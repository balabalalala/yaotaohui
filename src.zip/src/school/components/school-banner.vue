<template>
	<div class="banner-box">
		<ul> 
			<li class="active">
				中央美院
				<span></span>
			</li>
			<li>
				中国美院
				<span></span>
			</li>
			<li>
				清华美院
			</li>
		</ul>
		<img src="@/assets/school-img/meiyuan.png" alt="">
	</div>
</template>
<script >
	
</script>
<style scoped lang="stylus">
	.banner-box{
		// position absolute
		// left 0
		// top 0
		width: 100%;
		height: 220px;
		padding-bottom: 20px;
		background:#fff;
		ul{
			overflow: hidden;
			padding-top: 15px;
			padding-bottom: 15px;
			width: 100%;
			height: 25px;
			li{
				float: left;
				width: 33.33%;
				height: 25px;
				line-height: 25px;
				color: #8A8A8A;
				font-size: 18px;
				text-align: center;
				span{
					float: right;
					margin-top:3px;
					width: 1px;
					height: 16px;
					background-color: #E9E9E9;
				}
				img{
					float: left;
				}
			}
			li.active{
				color: #000000;
			}
		}
	}
</style>
